public class Node {
    Node left;
    Node right;
    int data;
}
