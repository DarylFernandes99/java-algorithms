public class BinaryTree {
    Node root;
}
