import java.util.Arrays;

public class Algorithms {

    public static void rotateArrayLeft(int[] arr) {
        
    }

    public static void main(String[] args) {
        int[] arr = { 1, 2, 3, 4, 5, 6 };
        rotateArrayLeft(arr);
        Arrays.stream(arr).forEach(System.out::println);
    }
}
