public class Algorithms {

    public static boolean isAtEvenIndex(String s, char item) {
        return false;
    }

    public static void main(String[] args) {

    }
}
