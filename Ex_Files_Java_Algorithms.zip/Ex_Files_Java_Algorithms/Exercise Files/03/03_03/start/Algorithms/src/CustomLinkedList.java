public class CustomLinkedList {

    Node head;
}
