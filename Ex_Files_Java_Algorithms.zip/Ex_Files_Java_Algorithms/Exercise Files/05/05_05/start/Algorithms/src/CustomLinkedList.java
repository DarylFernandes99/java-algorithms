public class CustomLinkedList {

    Node head;

    public boolean hasCycle() {
        return false;
    }
}
