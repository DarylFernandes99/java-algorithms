public class Algorithms {

    public static void main(String[] args) {

    }
}
